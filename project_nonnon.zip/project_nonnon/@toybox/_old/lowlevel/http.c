



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include <io.h>
#include <limits.h>


#include <windows.h>
#include <wininet.h>


//#include "../../../neutral/endian.c"




#define mb( s ) MessageBox( NULL, s, "", 0 )




void
n_http_save( HINTERNET http, const char *fname )
{

	const int bufsize = 1024 * 1024;


	FILE  *fp;
	char  *ptr;
	DWORD  size;


	if ( http == NULL ) { return; }


	fp = fopen( fname, "wb" );
	if ( fp == NULL ) { return; }


	ptr  = calloc( bufsize, 1 );
	size = 0;


	while( 1 )
	{

		InternetReadFile( http, ptr, bufsize, &size );

		fwrite( ptr, size, 1, fp );


		if ( size == 0 ) { break; }
	}


	free( ptr );


	fclose( fp );


	return;
}

int
main( int argc, char *argv[] )
{

	HINTERNET inet, session, http;

	//WIN32_FIND_DATA f;


	//if( InternetAttemptConnect( 0 ) ) { mb( "offline" ); }


	inet = InternetOpen
	(
		"NONNON TEST",
		INTERNET_OPEN_TYPE_DIRECT,
		NULL,NULL,
		0
	);

	if ( inet == NULL ) { mb( "inet" ); }


	session = InternetConnect
	(
		inet,
		"host",
		INTERNET_DEFAULT_HTTP_PORT,
		"",
		"",
		INTERNET_SERVICE_HTTP,
		0,0
	);

	if ( session == NULL ) { mb( "session" ); }


	http = InternetOpenUrl
	(
		inet,
		"http://",
		"Accept:*/*\r\n\r\n",
		strlen("Accept:*/*\r\n\r\n"),
		0,
		0
	);

	if ( http == NULL ) { mb( "http" ); }


/*
{

	DWORD  size;


	// returned size is invalid

	char str[ N_PATH_MAX ];

	size = 0;
	InternetQueryDataAvailable( http, &size, 0, 0 );

	//size = n_endian_swap( size, 4 );

	sprintf( str, "%d", (int) size );
	MessageBox( NULL, str, "", 0 );
}
*/
/*
{
	char str[ 256 ];


	DWORD size;


	ZeroMemory( str, 256 );

	size = 256;
	HttpQueryInfo( http, HTTP_QUERY_RAW_HEADERS_CRLF,str, &size, 0 );

	sprintf( str, "%s", str );
	MessageBox( NULL, str, "", 0 );
}
*/

n_http_save( http, "result.html" );


	InternetCloseHandle( http    );
	InternetCloseHandle( session );
	InternetCloseHandle( inet    );


	return 0;
}

