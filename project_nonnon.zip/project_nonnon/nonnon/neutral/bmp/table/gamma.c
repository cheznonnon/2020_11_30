// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_BMP_TABLE_GAMMA
#define _H_NONNON_NEUTRAL_BMP_TABLE_GAMMA




static bool n_bmp_table_gamma_onoff = false;


static double *n_bmp_table_gamma_1 = NULL;
static double *n_bmp_table_gamma_2 = NULL;
static double *n_bmp_table_gamma_3 = NULL;
static double *n_bmp_table_gamma_4 = NULL;
static double *n_bmp_table_gamma_5 = NULL;
static double *n_bmp_table_gamma_6 = NULL;
static double *n_bmp_table_gamma_7 = NULL;
static double *n_bmp_table_gamma_8 = NULL;
static double *n_bmp_table_gamma_9 = NULL;




double
n_bmp_table_gamma_calc( double n, double gamma )
{
	return 255.0 * pow( n_bmp_table_coeff_channel( n ), gamma );
}

void
n_bmp_table_gamma_init( void )
{

	if ( n_bmp_table_gamma_onoff != false ) { return; }


	n_bmp_table_gamma_1 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_2 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_3 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_4 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_5 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_6 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_7 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_8 = n_memory_new( 256 * sizeof( double ) );
	n_bmp_table_gamma_9 = n_memory_new( 256 * sizeof( double ) );


	int i = 0;
	while( 1 )
	{
		n_bmp_table_gamma_1[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.10 );
		n_bmp_table_gamma_2[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.20 );
		n_bmp_table_gamma_3[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.30 );
		n_bmp_table_gamma_4[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.40 );
		n_bmp_table_gamma_5[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.50 );
		n_bmp_table_gamma_6[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.60 );
		n_bmp_table_gamma_7[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.70 );
		n_bmp_table_gamma_8[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.80 );
		n_bmp_table_gamma_9[ i ] = -1;//n_bmp_table_gamma_calc( i, 0.90 );

		i++;
		if ( i >= 256 ) { break; }
	}


	n_bmp_table_gamma_onoff = true;


	return;
}

void
n_bmp_table_gamma_exit( void )
{

	if ( n_bmp_table_gamma_onoff == false ) { return; }


	n_memory_free( n_bmp_table_gamma_1 ); n_bmp_table_gamma_1 = NULL;
	n_memory_free( n_bmp_table_gamma_2 ); n_bmp_table_gamma_2 = NULL;
	n_memory_free( n_bmp_table_gamma_3 ); n_bmp_table_gamma_3 = NULL;
	n_memory_free( n_bmp_table_gamma_4 ); n_bmp_table_gamma_4 = NULL;
	n_memory_free( n_bmp_table_gamma_5 ); n_bmp_table_gamma_5 = NULL;
	n_memory_free( n_bmp_table_gamma_6 ); n_bmp_table_gamma_6 = NULL;
	n_memory_free( n_bmp_table_gamma_7 ); n_bmp_table_gamma_7 = NULL;
	n_memory_free( n_bmp_table_gamma_8 ); n_bmp_table_gamma_8 = NULL;
	n_memory_free( n_bmp_table_gamma_9 ); n_bmp_table_gamma_9 = NULL;


	n_bmp_table_gamma_onoff = false;


	return;
}




inline double
n_bmp_table_gamma_channel( double n, double gamma )
{

	if ( n_bmp_table_gamma_onoff == false )
	{
		atexit( n_bmp_table_gamma_exit );
		n_bmp_table_gamma_init();
	}


	if ( gamma == 0.0 )
	{
		return 255.00000000;
	}

	if ( gamma == 0.1 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_1[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_1[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.10 );
		}

		return v;
	}

	if ( gamma == 0.2 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_2[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_2[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.20 );
		}

		return v;
	}

	if ( gamma == 0.3 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_3[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_3[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.30 );
		}

		return v;
	}

	if ( gamma == 0.4 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_4[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_4[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.40 );
		}

		return v;
	}

	if ( gamma == 0.5 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_5[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.50 );
		}

		return v;
	}

	if ( gamma == 0.6 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_6[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_6[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.60 );
		}

		return v;
	}

	if ( gamma == 0.7 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_7[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_7[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.70 );
		}

		return v;
	}

	if ( gamma == 0.8 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_8[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_8[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.80 );
		}

		return v;
	}

	if ( gamma == 0.9 )
	{
		int elem = (int) n;

		register double v = n_bmp_table_gamma_9[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_gamma_9[ elem ] = v = n_bmp_table_gamma_calc( elem, 0.90 );
		}

		return v;
	}

	if ( gamma == 1.0 )
	{
		return 0.00000000;
	}


	return n_bmp_table_gamma_calc( n, gamma );
}


#endif // _H_NONNON_NEUTRAL_BMP_TABLE_GAMMA

