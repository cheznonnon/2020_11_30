// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_RANDOM
#define _H_NONNON_NEUTRAL_RANDOM




#include "./posix.c"




// [!] : for scalability

#define n_srand( seed ) srand( seed )
#define n_rand(       ) rand()




void
n_random_shuffle( void )
{

#ifdef N_POSIX_PLATFORM_WINDOWS

	u32 seed = n_posix_tickcount();

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	u32 seed = time( NULL );

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


	n_srand( seed );


	return;
}

u32
n_random_range( u32 n )
{

	if ( n == 0 ) { return 0; }

	return ( n_rand() % n );
}

u32
n_random_range_hiquality( u32 n )
{

	// [!] : 3x slower : slow but precise


	double d;


	d = (double) n_rand() / RAND_MAX;
	d = (double) d * n;


	// [!] : clamp is needed

	if ( d >= n ) { d = n - 1; }


	return (u32) d;
}


#endif // _H_NONNON_NEUTRAL_RANDOM

