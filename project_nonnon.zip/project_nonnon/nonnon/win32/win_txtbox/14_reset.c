// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_reset_undo( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// [Needed] : sy = 1 : a caret will disappear at the first time

	p->undo_cch_x  = 0;
	p->undo_cch_y  = 0;
	p->undo_cch_sx = 0;
	p->undo_cch_sy = 1;

	p->undo_line_min_onoff = false;
	p->undo_line_max_onoff = false;
	p->undo_line_min_cch_x = 0;
	p->undo_line_max_cch_x = 0;

	p->undo_onoff = false;


	n_txt_free( &p->txt_undo );
	n_txt_new ( &p->txt_undo );


	return;
}

void
n_win_txtbox_reset_scroll( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_reset( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_reset( &p->vscr );
	}


	return;
}

void
n_win_txtbox_reset_line_minmax( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->line_min_cch_x = N_WIN_TXTBOX_NOT_SELECTED;
	p->line_max_cch_x = N_WIN_TXTBOX_NOT_SELECTED;

	p->line_min_onoff = false;
	p->line_max_onoff = false;


	return;
}

void
n_win_txtbox_reset( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_txt_free( &p->txt );
	n_txt_new ( &p->txt );

	n_win_txtbox_scroll_set( p, 0,0,      false );
	n_win_txtbox_select_set( p, 0,0, 0,1, false );

	n_win_txtbox_reset_line_minmax( p );

	n_win_txtbox_reset_undo( p );

	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"EDIT" );

	n_win_txtbox_scaling( p );

	//n_win_txtbox_reset_scroll( p );

	n_bmp_fade_init( &p->fade, n_bmp_black );


	return;
}


